#include <stdio.h>
#include <math.h>


void merge(int arr[], int left, int middle, int right) {
	int n1 = middle - left + 1;
	int n2 = right - middle;

	int L[n1];
	int R[n2];

	int i = 0;
	int j = 0;
	int k = left;

	for (;i<n1;i++) {
		L[i] = arr[left + i];
	}
	for (;j<n2;j++) {
		R[j] = arr[middle + j + 1];
	}
	i = 0;
	j = 0;
	while (i < n1 && j <n2) {
		if (L[i] <= R[j]) {
			arr[k++] = L[i++];
		} else {
			arr[k++] = R[j++];
		}
	}	

	while (i<n1) {
		arr[k++] = L[i++];
	}

	while (j<n2) {
		arr[k++] = R[j++];
	}
}

void mergesort(int arr[], int left, int right) {
	if (left < right) {
		int middle = left + (right - left) / 2;

		mergesort(arr,left,middle);
		mergesort(arr,middle+1,right);

		merge(arr,left,middle,right);
	}
}


int main() {
	int arr[] = {1,39,2,4,7,1,23,5,7,9,2,4245,34,34534,2,3,5,4};
	int len = sizeof(arr) / sizeof(arr[0]);

	mergesort(arr,0,len-1);

	for (int i=0;i<len;i++){
		printf("%d, ", arr[i]);
	}
	printf("\n");
}
