#include <stdio.h>

void swap(int *a, int *b) {
	int t = *a;
	*a = *b;
	*b = t;
}

int partition(int arr[], int left, int right) {
	int pivot = arr[right];

	int i = left - 1;

	for (int j=left;j<right;j++) {
		if (arr[j] < pivot) {
			i++;
			swap(&arr[i],&arr[j]);
		}
	}

	swap(&arr[i+1],&arr[right]);
	return i+1;
	// fundamentally, you would want to partition such that
	// the pivot index is >= its leftist elements and <= rightist elements
	// do this repeatedly recursively is the idea of quicksort
}
void quicksort(int arr[], int left, int right) {
	if (left < right) {
		int pivot = partition(arr,left,right); // partition returns index of pivot
	
		quicksort(arr, left,pivot-1);
		quicksort(arr, pivot+1,right);
	}
}

int main() {
	int arr[] = {1,3,2,5,6,4};
	int len = sizeof(arr) / sizeof(arr[0]);
	quicksort(arr,0,len-1);
	for (int i=0;i<len;i++) {
		printf("%d, ",arr[i]);
	}
	printf("\n");
}

