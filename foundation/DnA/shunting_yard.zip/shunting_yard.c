/*
 * A very crude implementation
 * Just multiplication and addition
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

void push_char(char *str, char c, int size) {
	for (int i=0;i<size;i++) {
		if (str[i]=='\0') {
			str[i] = c;
			break;
		}
	}
}


void push_int(int *str, int c, int size) {
	for (int i=0;i<size;i++) {
		if (str[i]==0) {
			str[i] = c;
			break;
		}
	}
}

char pop_char(char *str, int size) {
	for (int i=size-1;i>=0;i--) {
		if (str[i]!='\0') {
			char c = str[i];
			str[i] = '\0';
			return c;
		}
	}
	return '\0';
}

int pop_int(int *str, int size) {
	for (int i=size-1;i>=0;i--) {
		if (str[i]!=0) {
			int c = str[i];
			str[i] = 0;
			return c;
		}
	}
}

void enqueue(char *str, char c, int size) {
	for (int i=0;i<size;i++) {
		if (!str[i]) {
			str[i] = c;
			break;
		}
	}
}

char dequeue(char *str, int size) {
	for (int i=0;i<size;i++) {
		if (str[i]) {
			char c = str[i];
		}
	}
	return '\0';
}

bool isEmpty_char(char *str) {
	return str[0]=='\0';	
}

bool isEmpty_int(int *str) {
	return str[0]==0;
}

int precedence(char op) {
    if (op == '*') return 2;
    if (op == '+') return 1;
    return 0;
}


char *infix_to_postfix(const char *str, int size) {
	char stack[size];
	char *queue = calloc(size+1,sizeof(char));
	memset(stack, '\0', sizeof(stack));
	memset(queue, '\0', sizeof(queue));

	for (int i=0;i<size;i++) {
		char c = str[i];
		if (c==' ') continue;
		if (c>='0' && c<='9') {
			enqueue(queue,c,size);
		} else if (c=='+' || c=='*') {
		    while (!isEmpty_char(stack) && precedence(stack[strlen(stack)-1]) >= precedence(c)) {
			enqueue(queue, pop_char(stack, size), size);
		    }
		    push_char(stack, c, size);
		}
		else if (c == '(') {
		    push_char(stack, c, size);
		} else if (c==')') {
			char ch;
			while ((ch=pop_char(stack,size))!='(') {
				enqueue(queue,ch,size);	
			}
		}
	}
	while (!isEmpty_char(stack)) {
		enqueue(queue,pop_char(stack,size),size);
	}
	return queue;
}

int eval(const char *str, int size) {
	int stack[size];
	memset(stack,0,sizeof(stack));

	for (int i=0;i<size;i++) {
		char c = str[i];
		if (c>='0' && c<='9') {
			int n = c - '0';
			push_int(stack,n,size);
		} else if (c=='+') {
			int a = pop_int(stack,size);
			int b = pop_int(stack, size);
			push_int(stack,a+b,size);
		} else if (c=='*') {
			int a = pop_int(stack,size);
			int b = pop_int(stack, size);
			push_int(stack,a*b,size);
		} 
	}	
	return stack[0];
}

int main() {
	const char *str = "3 + 4 * 5 + 8*2";
	int len = strlen(str);
	char *postfix = infix_to_postfix(str,len);
	int result = eval(postfix,len);
	printf("Result: %d.\n", result);
	free(postfix);
	return 0;
}




