#include <stdio.h>
#include <stdlib.h>
void swap(int *a, int *b) {
	int t = *a;
	*a = *b;
	*b = t;
}

struct DArray {
	int *arr;
	int size;
	int count;	
};

void resize_arr(struct DArray *a) {
	int *arr = calloc(a->size*2,sizeof(*arr));
	for (int i=0;i<a->count;i++) {
		arr[i] = a->arr[i];
	}	
	free(a->arr);
	a->arr = arr;
	a->size *= 2;
}

int parent(int i) { return (i-1) / 2; }

int leftChild(int i) { return i*2+1; }

int rightChild(int i) { return i*2 + 2; }

void shiftUp(int arr[], int i) {
	while (i>0 && arr[parent(i)] < arr[i]) {
		swap(&arr[parent(i)], &arr[i]);
		i = parent(i);
	}
}

void shiftDown(int arr[], int i, int size) {
	int maxIndex = i;
	int l = leftChild(i);

	if (l < size && arr[l] > arr[maxIndex]) maxIndex = l;
	int r = rightChild(i);
	if (r < size && arr[r] > arr[maxIndex]) maxIndex = r;

	if (i != maxIndex) {
		swap(&arr[i], &arr[maxIndex]);
		shiftDown(arr,maxIndex, size);
	}
}

void push_back(struct DArray *a, int val) {
	if (a->count==a->size) resize_arr(a);
	a->arr[a->count++] = val;
}

int pop(struct DArray *a) {
	if (a->count==0) return -1;
	int result = a->arr[0];
	a->arr[0] = a->arr[a->count-1];
	a->count--;
	shiftDown(a->arr,0,a->count);
	return result;
}

void insert(struct DArray *a, int val) {
	push_back(a,val);
	shiftUp(a->arr,a->count-1);
}

int getMax(struct DArray *a) {
	if (a->count==0) return -1;
	return a->arr[0];
}

void init(struct DArray *a, int n) {
	a->size=n;
	a->count=0;
	a->arr = calloc(n,sizeof(*a->arr));
}
int main() {
	struct DArray arr;
	init(&arr, 20);
	insert(&arr,30);	
	insert(&arr,4);
	insert(&arr,100);
	insert(&arr,2112);
	insert(&arr,6);

	while (arr.count > 0) {
		printf("%d ",pop(&arr));
	}
	printf("\n");
	free(arr.arr);
	return 0;
}
