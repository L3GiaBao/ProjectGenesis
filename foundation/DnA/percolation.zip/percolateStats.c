#include <stdlib.h>
#include "percolate.h"
#include <math.h>
#include <stdio.h>
#include <time.h>


long double mean(long double *attempts, int total_attempts) {
	long double result = 0.0L;
	for (int i=0;i<total_attempts;i++) {
		result += (long double)attempts[i];	
	}	
	result = result / (long double)total_attempts;
	return result;
}


long double stddv(long double *attempts, int total_attempts) {
	long double avg = mean(attempts,total_attempts);
	long double result = 0.0L;
	for (int i=0;i<total_attempts;i++) {
		long double k = (attempts[i]-avg)*(attempts[i]-avg) ;
		result += k;
	}
	result = result / (long double)(total_attempts-1);
	result = sqrtl(result);
	return result;
}


long double confidenceLo(long double *attempts, int total_attempts) {
	long double avg = mean(attempts,total_attempts);
	long double stdd = stddv(attempts,total_attempts);

	long double stder = stdd / sqrtl(total_attempts);

	stder = stder * (long double)1.96;
	return avg - stder;
}

long double confidenceHi(long double *attempts, int total_attempts) {
	long double avg = mean(attempts,total_attempts);
	long double stdd = stddv(attempts,total_attempts);

	long double stder = stdd / sqrtl(total_attempts);

	stder = stder * (long double)1.96;
	return avg + stder;
}

int main(int argc, char **argv) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <Grid-size> <Trials>\n", argv[0]);
        return 1; // Exit with an error code
    }
    srand(time(NULL));

    int grid_size = atoi(argv[1]);
    int trials = atoi(argv[2]);
    
    long double attempts[trials];

    for (int t = 0;t<trials;t++) {
    	struct perc perc = percolation(grid_size);
	int open_sites = 0;
	
   	while (!percolates(&perc)) {
		int row = rand() % (grid_size);
		int col = rand() % (grid_size);
		if (!isOpen(&perc,row,col)) {
			open(&perc,row,col);
			open_sites++;	
		}
	}		

	attempts[t] = (long double)open_sites / (long double)(grid_size*grid_size);
    }

    printf("Mean                    = %.20Lf\n",mean(attempts,trials));
    printf("Standard Deviation      = %.20Lf\n",stddv(attempts,trials));
    printf("95 percent confidence interval = [%.20Lf, %.20Lf]\n",confidenceLo(attempts,trials),confidenceHi(attempts,trials));
}
