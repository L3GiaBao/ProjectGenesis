#include <stdlib.h>
#include <string.h>
#include "percolate.h"

struct perc percolation(int n) {
	int i;
	struct perc perc;
	perc.n = n;
	perc.open = calloc(n,sizeof(*perc.open));
	for (i=0;i<n;i++) {
		perc.open[i] = calloc(n,sizeof(*perc.open[i]));
	}

	perc.uf.root = malloc(n*n*sizeof(*perc.uf.root));
	perc.uf.size = malloc(n*n*sizeof(*perc.uf.size));
	for (i=0;i<n*n;i++) {
		perc.uf.root[i] = i;
		perc.uf.size[i] = 1;
	}
	return perc;
	}

int find(struct perc *perc, int index) {
	if (index <0 || index >= perc->n*perc->n) return -1;
	while (perc->uf.root[index]!=index) {
		perc->uf.root[index] = perc->uf.root[perc->uf.root[index]];
		index = perc->uf.root[index];
	}
	return index;
}

void _union_(struct perc *perc, int a, int b) {
	if (a <0 || a >= perc->n*perc->n || b<0 || b>= perc->n*perc->n) return;
	int rootA = find(perc,a);
	int rootB = find(perc,b);
	if (rootA==rootB) return;

	if (perc->uf.size[rootA] > perc->uf.size[rootB]) {
		perc->uf.root[rootB] = rootA;
		perc->uf.size[rootA] += perc->uf.size[rootB];
	} else {
		perc->uf.root[rootA] = rootB;
		perc->uf.size[rootB] += perc->uf.size[rootA];
	}
}

void open(struct perc *perc, int row, int col) {
	if (row < 0 || row >= perc->n || col < 0 || col >= perc->n) return;
	perc->open[row][col] = true;

	const int dr[4] = {-1,1,0,0};
	const int dc[4] = {0,0,-1,1};
	int p = row*perc->n+col;	
	for (int k = 0; k < 4; k++) {
	    int nr = row + dr[k], nc = col + dc[k];
	    if ((unsigned)nr < (unsigned)perc->n && (unsigned)nc < (unsigned)perc->n
		&& perc->open[nr][nc]) {
		int q = nr*perc->n + nc;
		_union_(perc, p, q);
	    }
	}
}

bool isOpen(struct perc *perc, int row, int col) {
	if (row < 0 || row >= perc->n || col < 0 || col >= perc->n) return false;
	return perc->open[row][col];
}

bool isFull(struct perc *perc, int row, int col) {
	if (row < 0 || row >= perc->n || col < 0 || col >= perc->n) return false;
	int index = row*perc->n + col;
	int pid = find(perc,index);
	for (int i=0;i<perc->n;i++) {
		int qid = find(perc,i);
		if (pid==qid) return true;
	}
	return false;
}

int numberOfOpenSites(struct perc *perc) {
	int count = 0;
	for (int i=0;i<perc->n;i++) {
		for (int j=0;j<perc->n;j++) {
			if (perc->open[i][j]) count++;
		}
	}
	return count;
}

bool percolates(struct perc *perc) {
	for (int i=0;i<perc->n;i++) {
		if (isFull(perc,perc->n-1,i)) return true;
	}
	return false;
}
