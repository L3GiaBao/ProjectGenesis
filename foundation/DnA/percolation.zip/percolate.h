#include <stdbool.h>

struct UnionFind {
	int *root;
	int *size;
};

struct perc {
	int n;
	bool**open;
	struct UnionFind uf;
};

struct perc percolation(int n);

void open(struct perc *perc, int row, int col);

bool isOpen(struct perc *perc, int row, int col);

bool isFull(struct perc *perc, int row, int col);

int numberOfOpenSites(struct perc *perc);

bool percolates(struct perc *perc);


